
from flask import Flask, jsonify, request, render_template

from pymongo import MongoClient

#app = Flask(__name__)
app = Flask(__name__, template_folder='../templates')

client = MongoClient("mongodb+srv://user:Password1!@cluster0.ulx1s.mongodb.net/myFirstDatabase?ssl=true&ssl_cert_reqs=CERT_NONE")
db = client.get_database('Ethereum_db')


@app.route('/')
def index():
    
    posts = db.Ethereum_Market_Data.find({})
    return render_template('index.html', posts=posts)



@app.route('/google_charts')
def google_charts():
    posts = db.Ethereum_Market_Data.find({})
    return render_template('details.html', posts=posts)



if __name__ == "__main__":
    app.run()


